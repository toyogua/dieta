<div >

    <ul>
        <img src="assets/img/metodo-del-plato.png" class="img-fluid" alt="Dieta del Plato" >

    </ul>
</div>